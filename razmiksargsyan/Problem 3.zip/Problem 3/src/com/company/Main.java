package com.company;

public class Main {

    public static void main(String[] args) {
        int number1 = 91;
        int number2 = 8;
        System.out.println(number1/number2);
    }
}
